
import java.util.*;
public class ArrayListColors {
  public static void main(String[] args) {
  List<String> color = new ArrayList<String>();
  color.add("Red");
  color.add("Green");
  color.add("Orange");
  color.add("White");
  color.add("Black");
  
  System.out.println(color);
  }
}
