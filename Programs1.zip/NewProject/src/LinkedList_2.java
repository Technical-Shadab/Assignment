
import java.util.*;

public class LinkedList_2 {

	public static void main(String[] args) {
		
		List<String> list1 = new ArrayList<String>();
		
		
		list1.add("sha");
		list1.add("shad");
		list1.add("shada");
		list1.add("shadab");
		list1.add(null);
		
		Iterator itr1 = list1.iterator();
		
		/*while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}*/
		System.out.println(itr1.next());
	}

}
