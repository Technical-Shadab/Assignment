
import java.util.Iterator;
import java.util.LinkedList;

public class ReverseLinkedList {
	public static void main(String[] args)
	{
		LinkedList<String> linkedList = new LinkedList<>();
		
		linkedList.add("My");
		linkedList.add("name");
		linkedList.add("Shadab");
		linkedList.add("1997");
		linkedList.add("2021");


		Iterator<String> iterator = linkedList.descendingIterator();

		while (iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
	}
}
