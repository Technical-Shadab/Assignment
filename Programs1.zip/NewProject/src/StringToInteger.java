
import java.util.Scanner;

public class StringToInteger {

	public static void main(String[] args) {

		Scanner obj = new Scanner(System.in);
		String s = obj.next();
		try {
			int input = Integer.parseInt(s);
			System.out.println("this is integer"+input);
		} catch (NumberFormatException e) {
			
			System.out.println(e);
		}
		
	}

}
