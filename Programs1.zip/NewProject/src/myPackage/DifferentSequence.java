
package myPackage;

public class DifferentSequence {
    public void diffSequence(int n,char c)
    {
        System.out.println("Int "+n+" and char "+c);
    }
    public void diffSequence(char c,int n)
    {
        System.out.println("char "+c+" and char "+n);
    }
    public static void main(String args[])
    {
        DifferentSequence obj =new DifferentSequence();
        obj.diffSequence('a',10);
        obj.diffSequence(11,'b');
    }
}