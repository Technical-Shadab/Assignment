package myPackage;

import java.util.LinkedList;

public class LinkedListFirstLast2 {

	public static void main(String[] args) {
	
		
		LinkedList<String> l = new LinkedList<String>();
		
		l.add("a");
		l.add("b");
		l.add("c");
		
		l.addLast(l.get(1));
		
		System.out.println(l);

	}

}