



package myPackage;
import java.util.ArrayList;
import java.util.List;

public class StudentsData{

    String name;

    int age;

    String address;

    public Student()

    {

        this.name="unknown";

        this.age=0;

        this.address="not available";

    }

    public void setinfo(int age,String name)

    {

        this.name=name;

        this.age=age;

    }

    public void setinfo(int age ,String name,String address)

    {

        this.name=name;

        this.age=age;

        this.address=address;

    }

    @Override

    public String toString()

    {

        return "Student [name=" + name + ", age=" + age + ", address=" + address + "]";

    }

    public static void main(String[] args)

    {

        List<StudentsData> stu=new ArrayList<>();

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.add(new StudentsData());

        stu.get(0).setinfo(55, "Name1");

        stu.get(2).setinfo(50, "Name3","Delhi,India");

        stu.get(3).setinfo(45, "Name4","Patna,India");

        stu.get(5).setinfo(30, "Name6","Pune,India");

        stu.get(6).setinfo(65, "Name7","Mumbai,India");

        stu.get(8).setinfo(55, "Name9");

        for(StudentsData s :stu)

        {

            System.out.println(s);

        }

    }

}