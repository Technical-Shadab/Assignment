package myPackage;

public class StudentsDegree {

    public void getDegree() {
        System.out.println("I got a Degree");
    }
    public static void main(String[] args)
    {
    	StudentsDegree obj2 = new StudentsDegree();
        obj2.getDegree();
        undergraduate obj = new undergraduate();
        obj.degree();
        postgraduate obj1 = new postgraduate();
        obj1.degree();
    }
}
    class undergraduate
    {
        public void degree()
        {
            System.out.println("I am an Undergraduate");
        }
    }

    class postgraduate
    {
        public void degree()
        {
            System.out.println("I am a Postgraduate");
        }
    }
